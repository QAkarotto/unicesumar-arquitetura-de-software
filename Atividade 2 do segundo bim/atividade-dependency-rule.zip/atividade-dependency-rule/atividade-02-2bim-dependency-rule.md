# Atividade 02 - 2BIM: Dependency Rule e Limites Arquiteturais no FoodNow

**Integrante(s):** Pedro [+ nome da dupla, se aplicável]

> **Nota de escopo.** Não tenho acesso ao repositório real do FoodNow. As classes abaixo
> (`PagamentoService`, `FakePayPalClient`...) são **hipóteses coerentes com a arquitetura do projeto**
> (integrações simuladas, PayPal no subsistema de Pedidos). Troque pelos nomes reais ao copiar para o PR.
>
> **O que foi verificado de verdade:** o código da seção 4 e os testes da seção 5 estão em
> `exemplo-compilado/`, compilam com Java 21 e as verificações passam. **O que não pôde ser
> verificado:** `mvn clean verify`, JaCoCo e os testes de API do projeto real. O Maven Central é
> inacessível neste ambiente (falha de DNS), então a seção 6 é um roteiro para você rodar no seu repositório.

## 1. Dependência escolhida: pagamento (integração com PayPal, simulada)

Escolhi pagamento em vez de mapas para não repetir o que a Atividade 06 já tratou
(`ProvedorDeGeolocalizacao`). A regra "pedido confirmado vira pago se a cobrança for aprovada" é
política de negócio estável; PayPal é um detalhe que pode mudar.

## 2. Análise da direção atual das dependências

```
Antes:   PagamentoService  ──►  FakePayPalClient
         (regra de negócio)     (detalhe externo)
```

| Classe | Papel | Problema |
|---|---|---|
| `PagamentoService` | decide transição CONFIRMADO → PAGO / PAGAMENTO_RECUSADO | importa e instancia/injeta `FakePayPalClient` diretamente |
| `FakePayPalClient` | integração simulada, usa vocabulário do PayPal (`createOrder`, `status = "COMPLETED"`, `PayPalResponse`) | seu vocabulário vaza para a regra de negócio |

**Por que isso dificulta substituição, manutenção e teste:**
- **Substituição:** trocar PayPal por outro provedor obriga a editar `PagamentoService` (a regra),
  que não deveria mudar porque um fornecedor mudou. Mudanças em quem é estável forçadas por quem é volátil.
- **Manutenção:** o texto `"COMPLETED"` e a forma da resposta do PayPal estão dentro da regra; qualquer
  mudança na API do fornecedor atinge a política de pagamento.
- **Teste:** testar a regra exige instanciar ou mockar uma classe específica do PayPal. O teste fica
  acoplado ao detalhe, e não prova que a regra funciona independentemente do provedor.

Pergunta do enunciado: *se o FoodNow trocar o provedor, quais classes precisam mudar?* Antes:
`PagamentoService` + a configuração + os testes da regra. Depois: apenas uma nova classe de adaptador.

## 3. Decisão: limite entre regra da aplicação e detalhe externo

Criar a porta `PaymentGateway`, **pertencente à camada da regra de negócio** (pacote da aplicação, não da infraestrutura),
expressa em vocabulário do domínio (`cobrar(pedidoId, valor)` → `ResultadoCobranca(aprovada, codigoTransacao)`).
`PayPalPaymentGateway` a implementa e traduz para a API do PayPal. O Spring injeta a implementação (DI).

```
Depois:  PagamentoPedidoService ──► PaymentGateway ◄── PayPalPaymentGateway ──► FakePayPalClient
         (regra)                    (abstração/porta)    (adaptador)             (detalhe)
```

Pontos de projeto:
- A interface fica ao lado da regra: é ela quem define *o que precisa*, o detalhe se adapta. Esse é o
  coração da **inversão de dependência**: o código-fonte do adaptador passa a apontar para a abstração.
- O vocabulário do PayPal (`COMPLETED`, `PayPalResponse`) fica **dentro do adaptador**.
- Escopo localizado: só o fluxo de pagamento muda; endpoints, DTOs e contratos da API não são tocados.

## 4. Implementação (compilada em `exemplo-compilado/`)

```java
// Porta - pertence à regra da aplicação
public interface PaymentGateway {
    ResultadoCobranca cobrar(Long pedidoId, BigDecimal valor);
    record ResultadoCobranca(boolean aprovada, String codigoTransacao) {}
}

// Adaptador - único lugar que conhece FakePayPalClient
public class PayPalPaymentGateway implements PaymentGateway {
    private final FakePayPalClient client;
    public PayPalPaymentGateway(FakePayPalClient client) { this.client = client; }

    public ResultadoCobranca cobrar(Long pedidoId, BigDecimal valor) {
        var resp = client.createOrder("PEDIDO-" + pedidoId, valor);
        return new ResultadoCobranca("COMPLETED".equals(resp.status()), resp.id());
    }
}

// Regra - depende só da abstração
public class PagamentoPedidoService {
    private final PaymentGateway gateway;
    public PagamentoPedidoService(PaymentGateway gateway) { this.gateway = gateway; }

    public Status pagar(Long pedidoId, Status statusAtual, BigDecimal total) {
        if (statusAtual != Status.CONFIRMADO)
            throw new IllegalStateException("Pedido precisa estar CONFIRMADO para ser pago");
        return gateway.cobrar(pedidoId, total).aprovada() ? Status.PAGO : Status.PAGAMENTO_RECUSADO;
    }
}
```

No Spring, o adaptador vira `@Component` (ou `@Bean` em uma `@Configuration`) e o construtor do
serviço recebe `PaymentGateway`; não é preciso mudar nada na API. **Preservação do comportamento:** a
tradução `status == "COMPLETED"` → aprovada, o código `PP-...` e a regra de estado são exatamente os de antes.

## 5. Testes unitários

A regra é testada com um **stub do contrato** (uma lambda), sem nenhuma classe do PayPal:

| Teste | Mostra |
|---|---|
| aprovada → `PAGO` | regra sem infraestrutura |
| recusada → `PAGAMENTO_RECUSADO` | idem |
| status inválido → exceção e **gateway não chamado** | regra de estado protegida; stub falha se for chamado |
| adaptador: aprova e gera `PP-PEDIDO-7`; recusa valor zero | comportamento anterior preservado no limite |

Código em `exemplo-compilado/src/test/java/.../PagamentoPedidoServiceTest.java`. Os testes de API
existentes **não são alterados**.

**Evidência de direção de dependência** (verificada no exemplo): `grep -rl FakePayPalClient src/main`
lista apenas `FakePayPalClient.java` e `PayPalPaymentGateway.java`; a regra não o referencia.
No projeto real, vale ainda um teste de arquitetura (ArchUnit) proibindo `..pedido..` de depender de `..pagamento.paypal..`.

## 6. Roteiro: `mvn clean verify` (executar no repositório real)

1. `mvn clean verify` antes da mudança (guarde testes e cobertura).
2. Aplicar a refatoração; rodar de novo.
3. Conferir: testes de API intactos e verdes; novos testes passando; cobertura de linhas ≥ mínimo
   do projeto (a interface não tem linhas executáveis; o adaptador e a regra são cobertos pelos testes acima).
4. Registrar no PR: resultado do build, nº de testes e % de cobertura.

## 7. Resposta curta (pergunta do enunciado)

**Após a refatoração, em qual direção as dependências passaram a apontar e o que isso permite modificar com menor impacto?**
As dependências de código passaram a apontar para a abstração `PaymentGateway`, que fica do lado da regra
de negócio: a regra não conhece o PayPal, e o adaptador é que depende do contrato. Isso permite trocar o
provedor de pagamento (ou a simulação por uma integração real) escrevendo apenas um novo adaptador, e
testar a regra de pagamento sem infraestrutura, sem alterar `PagamentoPedidoService`, os endpoints ou os testes de API.

## Texto sugerido para o Pull Request

```markdown
## Atividade 02 - 2BIM: Dependency Rule e Limites Arquiteturais

**Integrante(s):** Pedro [+ dupla]

### Dependência escolhida
Integração de pagamento (PayPal simulado).

### Análise do problema
`PagamentoService -> FakePayPalClient`: a regra de pagamento dependia de uma classe concreta e do
vocabulário do PayPal ("COMPLETED"). Trocar de provedor exigia mudar a regra, e testá-la exigia a
classe do PayPal.

### Decisão adotada
Porta `PaymentGateway` (na camada da regra) + adaptador `PayPalPaymentGateway`. Injeção via construtor (Spring DI).

### Principais alterações
- Novo: `PaymentGateway`, `PayPalPaymentGateway`.
- Alterado: `PagamentoService` passa a depender apenas de `PaymentGateway`.
- Testes unitários da regra com stub do contrato; testes de API inalterados; contratos da API inalterados.

### mvn clean verify
[preencher: resultado, nº de testes, cobertura]

### Direção das dependências
`PagamentoService -> PaymentGateway <- PayPalPaymentGateway -> FakePayPalClient`. A regra deixou de
conhecer o provedor; trocar o provedor passa a exigir só um novo adaptador.
```
