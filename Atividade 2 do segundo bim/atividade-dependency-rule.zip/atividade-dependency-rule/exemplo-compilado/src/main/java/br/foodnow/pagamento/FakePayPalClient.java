package br.foodnow.pagamento;

import java.math.BigDecimal;

/** Detalhe externo (simulado). Conhece o "jeito PayPal"; a regra de negocio nao conhece esta classe. */
public class FakePayPalClient {
    public PayPalResponse createOrder(String reference, BigDecimal amount) {
        boolean ok = amount.signum() > 0;
        return new PayPalResponse(ok ? "COMPLETED" : "DECLINED", "PP-" + reference);
    }

    public record PayPalResponse(String status, String id) {}
}
