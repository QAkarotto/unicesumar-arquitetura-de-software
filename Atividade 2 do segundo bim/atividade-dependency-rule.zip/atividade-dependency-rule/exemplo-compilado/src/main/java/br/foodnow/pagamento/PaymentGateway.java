package br.foodnow.pagamento;

import java.math.BigDecimal;

/** Porta (abstracao) pertencente a regra da aplicacao: define O QUE o pedido precisa do pagamento. */
public interface PaymentGateway {
    ResultadoCobranca cobrar(Long pedidoId, BigDecimal valor);

    record ResultadoCobranca(boolean aprovada, String codigoTransacao) {}
}
