package br.foodnow.pagamento;

import java.math.BigDecimal;

/** Adaptador: traduz o contrato da aplicacao para a API do PayPal. Unico ponto que importa FakePayPalClient. */
public class PayPalPaymentGateway implements PaymentGateway {
    private final FakePayPalClient client;

    public PayPalPaymentGateway(FakePayPalClient client) {
        this.client = client;
    }

    @Override
    public ResultadoCobranca cobrar(Long pedidoId, BigDecimal valor) {
        var resp = client.createOrder("PEDIDO-" + pedidoId, valor);
        return new ResultadoCobranca("COMPLETED".equals(resp.status()), resp.id());
    }
}
