package br.foodnow.pedido;

import br.foodnow.pagamento.PaymentGateway;
import java.math.BigDecimal;

/** Regra da aplicacao: depende SOMENTE da abstracao PaymentGateway. */
public class PagamentoPedidoService {
    public enum Status { CONFIRMADO, PAGO, PAGAMENTO_RECUSADO }

    private final PaymentGateway gateway;

    public PagamentoPedidoService(PaymentGateway gateway) {
        this.gateway = gateway;
    }

    public Status pagar(Long pedidoId, Status statusAtual, BigDecimal total) {
        if (statusAtual != Status.CONFIRMADO) {
            throw new IllegalStateException("Pedido precisa estar CONFIRMADO para ser pago");
        }
        return gateway.cobrar(pedidoId, total).aprovada() ? Status.PAGO : Status.PAGAMENTO_RECUSADO;
    }
}
