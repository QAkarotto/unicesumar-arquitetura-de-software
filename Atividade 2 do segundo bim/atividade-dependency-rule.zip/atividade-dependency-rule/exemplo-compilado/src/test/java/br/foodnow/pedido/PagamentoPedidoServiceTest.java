package br.foodnow.pedido;

import static org.junit.jupiter.api.Assertions.*;

import br.foodnow.pagamento.*;
import br.foodnow.pedido.PagamentoPedidoService.Status;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class PagamentoPedidoServiceTest {

    /** Stub do contrato: nenhum PayPal, nenhuma classe de infraestrutura envolvida. */
    private static PaymentGateway gatewayQueRetorna(boolean aprovada) {
        return (id, valor) -> new PaymentGateway.ResultadoCobranca(aprovada, "TX-STUB");
    }

    @Test
    void pedidoConfirmadoComCobrancaAprovadaViraPago() {
        var service = new PagamentoPedidoService(gatewayQueRetorna(true));
        assertEquals(Status.PAGO, service.pagar(1L, Status.CONFIRMADO, new BigDecimal("30.00")));
    }

    @Test
    void cobrancaRecusadaGeraPagamentoRecusado() {
        var service = new PagamentoPedidoService(gatewayQueRetorna(false));
        assertEquals(Status.PAGAMENTO_RECUSADO, service.pagar(1L, Status.CONFIRMADO, new BigDecimal("30.00")));
    }

    @Test
    void pedidoNaoConfirmadoNaoPodeSerPagoENaoChamaOGateway() {
        PaymentGateway naoDeveSerChamado = (id, valor) -> { throw new AssertionError("gateway chamado"); };
        var service = new PagamentoPedidoService(naoDeveSerChamado);
        assertThrows(IllegalStateException.class, () -> service.pagar(1L, Status.PAGO, BigDecimal.TEN));
    }

    @Test
    void adaptadorPayPalPreservaComportamentoAnterior() {
        var gateway = new PayPalPaymentGateway(new FakePayPalClient());
        var ok = gateway.cobrar(7L, new BigDecimal("12.50"));
        assertTrue(ok.aprovada());
        assertEquals("PP-PEDIDO-7", ok.codigoTransacao());
        assertFalse(gateway.cobrar(7L, BigDecimal.ZERO).aprovada());
    }
}
